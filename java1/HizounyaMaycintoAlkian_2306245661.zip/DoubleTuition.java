public class DoubleTuition {
    // atribut
    double initialTuition;
    double tuition;
    int year;

    // Constructor
    public DoubleTuition(double initialTuition, double tuition, int year) {
        this.initialTuition = initialTuition;
        this.tuition = tuition;
        this.year = year;
    }

    // Getter
    public double getInitialTuition() {
        return initialTuition;
    }

    public double getTuition() {
        return tuition;
    }

    public int getYear() {
        return year;
    }

    // Setter
    public void setInitialTuition(double initialTuition) {
        this.initialTuition = initialTuition;
    }

    public void setTuition(double tuition) {
        this.tuition = tuition;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int countYear() {
        while (tuition < (2 * initialTuition)) {
            tuition = tuition * 1.07;
            year++;
        }
        return year;
    }

    public static void main(String[] args) {
        double initialTuition = 10000;
        double tuition = initialTuition;   // Year 0
        int year = 0;
        DoubleTuition tuitionCalculator = new DoubleTuition(initialTuition, tuition, year);
        year = tuitionCalculator.countYear();
        tuition = tuitionCalculator.getTuition();
        System.out.println("Tuition will be doubled in " + year + " years");
        System.out.printf("Tuition will be $%.2f in %1d years", tuition, year);
    }
}